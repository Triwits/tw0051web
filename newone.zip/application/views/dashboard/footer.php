<!-- Main Footer-->
			<div class="main-footer text-center" style="background-color:#73D3DD">
				<div class="container">
					<div class="row">
						<div class="col-md-12">
							<span style="color: #fff;"> Crafted with &nbsp;<i class="fa fa-heart" style="color:red"></i>&nbsp; by <a style=" cursor: pointer; color: blue;" data-toggle="modal" data-target="#modalCentered">Triwits</a></span>
						</div>
					</div>
				</div>
			</div>
			<!--End Footer-->

			<div class="modal fade" id="modalCentered" tabindex="-1" role="dialog">
      <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
         <!--  <div class="modal-header">
            <h4 align="center">Need a similiar website?</h4>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close"></button>
          </div> -->
          <div class="modal-body">
            <h4 align="center">Need a similar website?</h4>
            <div class="row">
            <div class="col-md-12" align="center">
              <a style="width : 150px;" class="btn btn-success" target = "_blank"  
              href="https://wa.me/919620030308?text=Need+a+website.+Please+help" data-action="share/whatsapp/share">Yes</a>&nbsp;
              <a style="width : 150px;"  target='_blank' style="color: white;" class="btn btn-warning" href="https://www.triwits.com/">May be later..</a>
             </div>
              
            </div>
          </div>
          <!-- <div class="modal-footer">
            <button class="btn btn-outline-secondary btn-sm" type="button" data-dismiss="modal">Close</button>
            <button class="btn btn-primary btn-sm" type="button">Save changes</button>
          </div> -->
        </div>
      </div>
    </div>

		</div>
		<!-- End Page -->

		<!-- Back-to-top -->
		<a href="#top" id="back-to-top"><i class="fe fe-arrow-up"></i></a>

		<!-- Jquery js-->
		<script src="<?php echo base_url()?>assets/plugins/jquery/jquery.min.js"></script>

		<!-- Bootstrap js-->
		<script src="<?php echo base_url()?>assets/plugins/bootstrap/js/popper.min.js"></script>
		<script src="<?php echo base_url()?>assets/plugins/bootstrap/js/bootstrap.min.js"></script>

		<!--Internal Apexchart js-->
		<script src="<?php echo base_url()?>assets/js/apexcharts.js"></script>

		<!-- Internal Chart.Bundle js-->
		<script src="<?php echo base_url()?>assets/plugins/chart.js/Chart.bundle.min.js"></script>


		<!-- Peity js-->
		<script src="<?php echo base_url()?>assets/plugins/peity/jquery.peity.min.js"></script>

		<!-- Select2 js-->
		<script src="<?php echo base_url()?>assets/plugins/select2/js/select2.min.js"></script>

		<!-- Internal Data Table js -->
		<script src="<?php echo base_url()?>assets/plugins/datatable/jquery.dataTables.min.js"></script>
		<script src="<?php echo base_url()?>assets/plugins/datatable/dataTables.bootstrap4.min.js"></script>
		<script src="<?php echo base_url()?>assets/js/table-data.js"></script>
		<script src="<?php echo base_url()?>assets/plugins/datatable/dataTables.responsive.min.js"></script>
		<script src="<?php echo base_url()?>assets/plugins/datatable/fileexport/dataTables.buttons.min.js"></script>
		<script src="<?php echo base_url()?>assets/plugins/datatable/fileexport/buttons.bootstrap4.min.js"></script>


		<!-- Perfect-scrollbar js -->
		<script src="<?php echo base_url()?>assets/plugins/perfect-scrollbar/perfect-scrollbar.min.js"></script>

		<!-- Select2 js-->
		<script src="<?php echo base_url()?>assets/plugins/select2/js/select2.min.js"></script>
		<script src="<?php echo base_url()?>assets/js/select2.js"></script>

		<!-- Sidebar js -->
		<script src="<?php echo base_url()?>assets/plugins/sidebar/sidebar.js"></script>

		<!-- INTERNAL INDEX js -->
		<script src="<?php echo base_url()?>assets/js/index.js"></script>

		<!-- Sticky js -->
		<script src="<?php echo base_url()?>assets/js/sticky.js"></script>

		<!-- Custom js -->
		<script src="<?php echo base_url()?>assets/js/custom.js"></script>

		<!-- Switcher js -->
		<script src="<?php echo base_url()?>assets/switcher/js/switcher.js"></script>


	</body>

<!-- Mirrored from www.spruko.com/demo/dashpro/Dashpro/HTML-LTR/Horizontal-light/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 22 Jan 2022 05:23:11 GMT -->
</html>