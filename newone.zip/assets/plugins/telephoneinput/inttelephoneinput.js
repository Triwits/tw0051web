$(function() {
    $("#mobile-number").intlTelInput();
});

